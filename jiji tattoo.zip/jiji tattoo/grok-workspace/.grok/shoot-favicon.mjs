import { chromium } from "playwright";
import { pathToFileURL } from "node:url";
import { writeFileSync } from "node:fs";

writeFileSync(
  "/workspace/.grok/favicon-preview.html",
  `<!DOCTYPE html>
<html><body style="margin:0;background:#888">
  <div style="display:flex;gap:24px;padding:16px;align-items:flex-end">
    <img src="${pathToFileURL("/workspace/public/favicon.svg").href}" width="16" height="16" />
    <img src="${pathToFileURL("/workspace/public/favicon.svg").href}" width="32" height="32" />
    <img src="${pathToFileURL("/workspace/public/favicon.svg").href}" width="64" height="64" />
  </div>
</body></html>`,
);

const browser = await chromium.launch({
  executablePath:
    "/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell",
  headless: true,
  args: ["--allow-file-access-from-files"],
});
const page = await browser.newPage({
  viewport: { width: 280, height: 120 },
  deviceScaleFactor: 2,
});
await page.goto(pathToFileURL("/workspace/.grok/favicon-preview.html").href, {
  waitUntil: "networkidle",
});
await page.screenshot({ path: "/workspace/.grok/favicon-preview.png", type: "png" });
await browser.close();
console.log("favicon preview written");
