export const QUOTE_SIZES = [
  { id: "xs", label: "Petit — jusqu'à 8 cm", hint: "un motif, une séance courte", base: 9000 },
  { id: "s", label: "Moyen — 8 à 15 cm", hint: "le format le plus demandé", base: 18000 },
  { id: "m", label: "Grand — 15 à 25 cm", hint: "une à deux séances", base: 32000 },
  { id: "l", label: "Très grand / demi-manchette", hint: "plusieurs séances", base: 65000 },
  { id: "xl", label: "Pièce complète", hint: "dos, manchette, projet long", base: 120000 },
] as const;

export const QUOTE_PLACEMENTS = [
  { id: "avant-bras", label: "Avant-bras", factor: 1 },
  { id: "bras", label: "Bras / épaule", factor: 1 },
  { id: "mollet", label: "Mollet", factor: 1 },
  { id: "cuisse", label: "Cuisse", factor: 1.05 },
  { id: "dos", label: "Dos", factor: 1.1 },
  { id: "poitrine", label: "Poitrine", factor: 1.12 },
  { id: "cotes", label: "Côtes / sternum", factor: 1.28 },
  { id: "main", label: "Main / doigt", factor: 1.32 },
  { id: "pied", label: "Pied / cheville", factor: 1.25 },
  { id: "cou", label: "Cou / nuque", factor: 1.38 },
] as const;

export const QUOTE_STYLES = [
  { id: "fineline", label: "Fineline", factor: 1 },
  { id: "botanique", label: "Botanique / floral", factor: 1.06 },
  { id: "lettering", label: "Lettering", factor: 0.95 },
  { id: "geometrique", label: "Géométrique", factor: 1.1 },
  { id: "blackwork", label: "Blackwork", factor: 1.16 },
  { id: "japonais", label: "Japonais", factor: 1.22 },
  { id: "realisme", label: "Réalisme", factor: 1.35 },
  { id: "couleur", label: "Couleur / aquarelle", factor: 1.28 },
] as const;

export type QuoteInput = {
  size: string;
  placement: string;
  style: string;
  color: "noir" | "couleur";
  coverup: boolean;
};

export function estimateQuote(input: QuoteInput) {
  const size = QUOTE_SIZES.find((s) => s.id === input.size) ?? QUOTE_SIZES[1];
  const placement = QUOTE_PLACEMENTS.find((p) => p.id === input.placement) ?? QUOTE_PLACEMENTS[0];
  const style = QUOTE_STYLES.find((s) => s.id === input.style) ?? QUOTE_STYLES[0];
  let amount = size.base * placement.factor * style.factor;
  if (input.color === "couleur" && input.style !== "couleur") amount *= 1.18;
  if (input.coverup) amount *= 1.35;
  const mid = Math.round(amount / 100) * 100;
  const min = Math.round((mid * 0.86) / 100) * 100;
  const max = Math.round((mid * 1.22) / 100) * 100;
  const deposit = Math.round((mid * 0.3) / 100) * 100;
  return { min, mid, max, deposit };
}
