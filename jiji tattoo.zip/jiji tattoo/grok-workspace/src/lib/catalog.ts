export type ServiceKind = "tatouage" | "piercing" | "soin";

export type Artist = {
  id: string;
  name: string;
  role: string;
  bio: string;
  specialties: string[];
  image: string;
  services: ServiceKind[];
};

export type Work = {
  id: string;
  title: string;
  artistId: string;
  category: ServiceKind;
  style: string;
  placement: string;
  image: string;
  featured?: boolean;
  tall?: boolean;
};

export type Product = {
  id: string;
  name: string;
  tagline: string;
  description: string;
  price: number;
  image: string;
  volume: string;
  category: "aftercare" | "visage" | "piercing";
  notes: string[];
};

export const SALON = {
  name: "Jiji Tattoo",
  tagline: "L'encre, la peau, le soin.",
  email: "hello@jiji.tattoo",
  phone: "01 43 18 27 40",
  hours: "Mardi — Samedi, 11 h – 19 h",
  addressNote: "Atelier privé, visites sur rendez-vous. L'adresse est confirmée à la réservation.",
  response: "Réponse sous deux heures, du mardi au samedi.",
};

export const ARTISTS: Artist[] = [
  {
    id: "jiji",
    name: "Jiji",
    role: "Fondatrice · tatouage",
    bio: "Jiji ouvre l'atelier comme on ouvre une maison : lumière basse, linge propre, le temps qu'il faut. Botanique, fineline, pièces qui vieillissent avec la peau.",
    specialties: ["Botanique", "Fineline", "Hibiscus & floral"],
    image: "/images/jiji-portrait.jpg",
    services: ["tatouage", "soin"],
  },
  {
    id: "noah",
    name: "Noah",
    role: "Tatouage",
    bio: "Noir dense, structures, japonais contemporain. Noah dessine longtemps avant d'allumer la machine — les grandes pièces se méritent.",
    specialties: ["Blackwork", "Japonais", "Géométrie"],
    image: "/images/artist-noah.jpg",
    services: ["tatouage"],
  },
  {
    id: "mira",
    name: "Mira",
    role: "Piercing & couleur",
    bio: "Mira pose le bijou comme on pose une phrase. Anatomie, cicatrisation, et les pièces réalistes qu'on vient lui redemander.",
    specialties: ["Piercing", "Réalisme", "Couleur"],
    image: "/images/artist-mira.jpg",
    services: ["piercing", "tatouage"],
  },
];

export const WORKS: Work[] = [
  {
    id: "hibiscus-épaule",
    title: "Hibiscus d'épaule",
    artistId: "jiji",
    category: "tatouage",
    style: "Botanique",
    placement: "Épaule",
    image: "/images/jiji-portrait.jpg",
    featured: true,
    tall: true,
  },
  {
    id: "session",
    title: "Séance en cours",
    artistId: "noah",
    category: "tatouage",
    style: "Blackwork",
    placement: "Avant-bras",
    image: "/images/work-session.jpg",
    featured: true,
    tall: true,
  },
  {
    id: "geo-bras",
    title: "Tracé géométrique",
    artistId: "noah",
    category: "tatouage",
    style: "Géométrie",
    placement: "Bras",
    image: "/images/work-artist-arm.jpg",
    featured: true,
  },
  {
    id: "papillon",
    title: "Papillons d'épaule",
    artistId: "jiji",
    category: "tatouage",
    style: "Fineline",
    placement: "Épaule",
    image: "/images/work-session-2.jpg",
    featured: true,
    tall: true,
  },
  {
    id: "plastron",
    title: "Plastron ornemental",
    artistId: "noah",
    category: "tatouage",
    style: "Géométrie",
    placement: "Poitrine",
    image: "/images/work-close.jpg",
    featured: true,
  },
  {
    id: "dos-floral",
    title: "Pièce de dos",
    artistId: "mira",
    category: "tatouage",
    style: "Réalisme",
    placement: "Dos",
    image: "/images/work-backpiece.jpg",
    featured: true,
    tall: true,
  },
  {
    id: "dos-ornement",
    title: "Dos ornemental",
    artistId: "noah",
    category: "tatouage",
    style: "Japonais",
    placement: "Dos",
    image: "/images/work-flash.jpg",
    tall: true,
  },
  {
    id: "pivoine",
    title: "Pivoine d'épaule",
    artistId: "jiji",
    category: "tatouage",
    style: "Botanique",
    placement: "Épaule",
    image: "/images/work-line.jpg",
    featured: true,
  },
  {
    id: "manchette",
    title: "Manchette hibou",
    artistId: "mira",
    category: "tatouage",
    style: "Couleur",
    placement: "Bras",
    image: "/images/work-sleeve.jpg",
    tall: true,
  },
  {
    id: "lumiere-basse",
    title: "Lumière basse",
    artistId: "noah",
    category: "tatouage",
    style: "Blackwork",
    placement: "Avant-bras",
    image: "/images/work-studio-dark.jpg",
  },
  {
    id: "fauteuil",
    title: "Au fauteuil",
    artistId: "jiji",
    category: "tatouage",
    style: "Botanique",
    placement: "Bras",
    image: "/images/jiji-studio.jpg",
    tall: true,
  },
  {
    id: "helix",
    title: "Industrial",
    artistId: "mira",
    category: "piercing",
    style: "Oreille",
    placement: "Helix",
    image: "/images/pierce-ear.jpg",
    featured: true,
    tall: true,
  },
  {
    id: "oreille-or",
    title: "Composition d'oreille",
    artistId: "mira",
    category: "piercing",
    style: "Oreille",
    placement: "Lobe & helix",
    image: "/images/jewel-gold.jpg",
    featured: true,
  },
  {
    id: "bagues",
    title: "Bijoux d'atelier",
    artistId: "mira",
    category: "piercing",
    style: "Or 14k",
    placement: "Vitrine",
    image: "/images/jewel-rings.jpg",
  },
  {
    id: "portrait-encre",
    title: "Portrait encré",
    artistId: "jiji",
    category: "tatouage",
    style: "Botanique",
    placement: "Bras",
    image: "/images/pierce-navel.jpg",
  },
];

export const PRODUCTS: Product[] = [
  {
    id: "baume-cicatrisant",
    name: "Baume cicatrisant",
    tagline: "Les quinze premiers jours.",
    description:
      "Beurre de karité, cire d'abeille et calendula. Une couche fine, deux fois par jour, dès que le film n'est plus là. Sans parfum, sans huile essentielle.",
    price: 2800,
    image: "/images/cream-jar.jpg",
    volume: "50 ml",
    category: "aftercare",
    notes: ["Sans parfum", "Tatouage frais", "Karité & calendula"],
  },
  {
    id: "huile-botanique",
    name: "Huile botanique",
    tagline: "Quand l'encre a pris.",
    description:
      "Jojoba, rose musquée et extraits de hibiscus. Pour les pièces cicatrisées qu'on veut garder souples, profondes, sans tiraillement.",
    price: 3600,
    image: "/images/oil-bottle.jpg",
    volume: "30 ml",
    category: "aftercare",
    notes: ["Pièces cicatrisées", "Hibiscus", "Texture sèche"],
  },
  {
    id: "serum-barriere",
    name: "Sérum barrière",
    tagline: "La peau autour de l'encre.",
    description:
      "Céramides et panthénol. Un fluide que l'on met le matin sur le visage et le décolleté — y compris quand on a une pièce récente à côté.",
    price: 4200,
    image: "/images/serum.jpg",
    volume: "30 ml",
    category: "visage",
    notes: ["Céramides", "Visage", "Tous les jours"],
  },
  {
    id: "lait-nettoyant",
    name: "Lait nettoyant",
    tagline: "Ni grincement, ni parfum.",
    description:
      "Un lait qui enlève la journée sans décaper. Premier geste du rituel aftercare, et le seul nettoyant que l'atelier recommande les deux premières semaines.",
    price: 2400,
    image: "/images/prod-bottles.jpg",
    volume: "150 ml",
    category: "visage",
    notes: ["pH doux", "Aftercare", "Sans savon"],
  },
  {
    id: "kit-aftercare",
    name: "Kit aftercare",
    tagline: "Tout ce qu'il faut, rien d'autre.",
    description:
      "Film de protection, lait nettoyant, baume, compresses. Remis à la fin de séance, ou commandé pour une pièce faite ailleurs.",
    price: 6800,
    image: "/images/prod-spa.jpg",
    volume: "Coffret",
    category: "aftercare",
    notes: ["Film + baume + lait", "15 jours", "Le plus demandé"],
  },
  {
    id: "creme-jour",
    name: "Crème de jour SPF 50",
    tagline: "L'encre a horreur du soleil.",
    description:
      "Écran minéral, texture sèche. Obligatoire dès que la pièce est cicatrisée — et fortement conseillée sur tout le visage, pièce ou non.",
    price: 2600,
    image: "/images/prod-cream2.jpg",
    volume: "40 ml",
    category: "visage",
    notes: ["SPF 50", "Minéral", "Pièces cicatrisées"],
  },
  {
    id: "spray-piercing",
    name: "Spray piercing",
    tagline: "Solution isotonique, rien d'autre.",
    description:
      "Spray stérile pour le nettoyage biquotidien. Pas d'alcool, pas d'huile essentielle, pas de « désinfectant » de pharmacie.",
    price: 1600,
    image: "/images/prod-serum2.jpg",
    volume: "100 ml",
    category: "piercing",
    notes: ["Isotonique", "Stérile", "2 × par jour"],
  },
  {
    id: "huile-precieuse",
    name: "Huile précieuse",
    tagline: "Soir, visages marqués.",
    description:
      "Une huile sèche pour le soir. Relance l'éclat autour des pièces anciennes, sans film gras. Seule, ou sur le sérum barrière.",
    price: 3800,
    image: "/images/prod-oils.jpg",
    volume: "20 ml",
    category: "visage",
    notes: ["Soir", "Texture sèche", "Visage & décolleté"],
  },
];

export const TIME_SLOTS = ["11:00", "12:00", "14:00", "15:30", "17:00", "18:30"] as const;

export const SERVICES: {
  id: ServiceKind;
  title: string;
  kicker: string;
  body: string;
  image: string;
}[] = [
  {
    id: "tatouage",
    title: "Tatouage",
    kicker: "La maison d'encre",
    body: "Consultation d'abord, dessin ensuite, séance quand c'est prêt. Fineline, botanique, blackwork, japonais, réalisme. On ne force pas une date.",
    image: "/images/work-artist-arm.jpg",
  },
  {
    id: "piercing",
    title: "Piercing",
    kicker: "Le bijou juste",
    body: "Anatomie, bijou d'atelier, protocole stérile. Oreille, nez, et les poses qui demandent de s'asseoir deux minutes de plus.",
    image: "/images/pierce-ear.jpg",
  },
  {
    id: "soin",
    title: "Soin de peau",
    kicker: "Ce qui reste après l'aiguille",
    body: "Cicatrisants, barrière, soleil. Les formules de l'atelier, et un rendez-vous d'une demi-heure pour celles et ceux qui ne savent plus quoi mettre.",
    image: "/images/serum.jpg",
  },
];

export const AMENITIES = [
  {
    title: "Séance",
    items: ["Consultation offerte", "Dessin original", "Créneau bloqué pour vous"],
  },
  {
    title: "Hygiène",
    items: ["Matériel à usage unique", "Autoclave", "Bijoux implant-grade"],
  },
  {
    title: "Après",
    items: ["Kit aftercare", "Consignes écrites", "Retour à 15 jours"],
  },
];

export type SeedReview = {
  id: string;
  name: string;
  role: string;
  service: ServiceKind;
  rating: number;
  body: string;
  image: string;
};

export const SEED_REVIEWS: SeedReview[] = [
  {
    id: "r1",
    name: "Camille B.",
    role: "Hibiscus d'épaule, 2025",
    service: "tatouage",
    rating: 5,
    body: "Jiji a tenu le dessin trois semaines, jusqu'à ce qu'il soit le mien. Le jour J, personne n'a parlé trop fort. L'épaule a cicatrisé comme on le lui avait dit.",
    image: "/images/jiji-portrait.jpg",
  },
  {
    id: "r2",
    name: "Idriss M.",
    role: "Blackwork, avant-bras",
    service: "tatouage",
    rating: 5,
    body: "Noah a refusé le premier motif. Il avait raison. La pièce tient, nette, et le kit aftercare m'a évité les erreurs de forum.",
    image: "/images/work-session.jpg",
  },
  {
    id: "r3",
    name: "Léa S.",
    role: "Industrial, oreille gauche",
    service: "piercing",
    rating: 5,
    body: "Mira a mesuré trois fois, changé de bijou une fois. Ça n'a pas gonflé. Le spray de l'atelier est le seul que je garde.",
    image: "/images/pierce-ear.jpg",
  },
  {
    id: "r4",
    name: "Yasmine K.",
    role: "Soin barrière + SPF",
    service: "soin",
    rating: 5,
    body: "Ma pièce de dos passait au gris. On m'a vendu de la crème, pas un discours. En six semaines, l'encre a repris de la densité.",
    image: "/images/work-flash.jpg",
  },
];

export function artistById(id: string) {
  return ARTISTS.find((a) => a.id === id);
}

export function productById(id: string) {
  return PRODUCTS.find((p) => p.id === id);
}

export function workById(id: string) {
  return WORKS.find((w) => w.id === id);
}
