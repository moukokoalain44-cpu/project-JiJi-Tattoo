import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { ServiceKind } from "./catalog";
import { uid } from "./utils";

export type CartItem = {
  productId: string;
  qty: number;
};

export type Booking = {
  id: string;
  service: ServiceKind;
  artistId: string;
  date: string;
  time: string;
  name: string;
  contact: string;
  notes: string;
  createdAt: string;
};

export type QuoteRequest = {
  id: string;
  name: string;
  contact: string;
  size: string;
  placement: string;
  style: string;
  color: "noir" | "couleur";
  coverup: boolean;
  description: string;
  reference?: string;
  min: number;
  max: number;
  createdAt: string;
};

export type Review = {
  id: string;
  name: string;
  service: ServiceKind;
  rating: number;
  body: string;
  images: string[];
  createdAt: string;
};

export type Order = {
  id: string;
  items: { productId: string; qty: number; name: string; price: number }[];
  total: number;
  name: string;
  contact: string;
  fulfillment: "retrait" | "livraison";
  createdAt: string;
};

type State = {
  cart: CartItem[];
  bookings: Booking[];
  quotes: QuoteRequest[];
  reviews: Review[];
  orders: Order[];
  addToCart: (productId: string, qty?: number) => void;
  setQty: (productId: string, qty: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  addBooking: (b: Omit<Booking, "id" | "createdAt">) => Booking;
  addQuote: (q: Omit<QuoteRequest, "id" | "createdAt">) => QuoteRequest;
  addReview: (r: Omit<Review, "id" | "createdAt">) => Review;
  addOrder: (o: Omit<Order, "id" | "createdAt">) => Order;
};

export const useSalon = create<State>()(
  persist(
    (set, get) => ({
      cart: [],
      bookings: [],
      quotes: [],
      reviews: [],
      orders: [],
      addToCart: (productId, qty = 1) => {
        const cart = [...get().cart];
        const i = cart.findIndex((c) => c.productId === productId);
        if (i >= 0) cart[i] = { ...cart[i], qty: cart[i].qty + qty };
        else cart.push({ productId, qty });
        set({ cart });
      },
      setQty: (productId, qty) => {
        if (qty <= 0) {
          set({ cart: get().cart.filter((c) => c.productId !== productId) });
          return;
        }
        set({
          cart: get().cart.map((c) => (c.productId === productId ? { ...c, qty } : c)),
        });
      },
      removeFromCart: (productId) =>
        set({ cart: get().cart.filter((c) => c.productId !== productId) }),
      clearCart: () => set({ cart: [] }),
      addBooking: (b) => {
        const row: Booking = { ...b, id: uid(), createdAt: new Date().toISOString() };
        set({ bookings: [row, ...get().bookings] });
        return row;
      },
      addQuote: (q) => {
        const row: QuoteRequest = { ...q, id: uid(), createdAt: new Date().toISOString() };
        set({ quotes: [row, ...get().quotes] });
        return row;
      },
      addReview: (r) => {
        const row: Review = { ...r, id: uid(), createdAt: new Date().toISOString() };
        set({ reviews: [row, ...get().reviews] });
        return row;
      },
      addOrder: (o) => {
        const row: Order = { ...o, id: uid(), createdAt: new Date().toISOString() };
        set({ orders: [row, ...get().orders] });
        return row;
      },
    }),
    { name: "jiji-tattoo" },
  ),
);

export function cartCount(cart: CartItem[]) {
  return cart.reduce((n, i) => n + i.qty, 0);
}
